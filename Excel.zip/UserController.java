package com.dxz.web.portal.controller;

import com.alibaba.fastjson.JSON;
import com.dxz.common.core.dwz.ApiResult;

import com.dxz.common.core.page.PageQuery;
import com.dxz.common.core.utils.RandomNumUtil;
import com.dxz.common.core.utils.UUIDUtils;
import com.dxz.core.model.UserEntity;
import com.dxz.service.user.ApiUserService;
import com.dxz.web.portal.utils.ConverterUtils;
import com.dxz.web.portal.utils.ExlExport;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.*;

/**
* @ClassName: LecturerController 
* @Description: 讲师信息控制类
* @author xks
* @date 2018年6月27日 下午2:31:52  
*/
@Controller
@RequestMapping("/web-api/user")
public class UserController {
    

    @RequestMapping("export")
    public void export(HttpServletResponse response){
        SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        List<Map<String, Object>> headList = new ArrayList<>();
        for (int i=0;i<100;i++){
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("code",UUIDUtils.getUUID());
            map.put("name","SC"+i);
            map.put("type",(new Random().nextInt(2))>0?"Y":"N");
            map.put("sum",new Random().nextInt()+1000);
            headList.add(map);
        }
        String[] array = new String[]{"序号","订单编号","商品名称","商品类型","总金额"};
        List<String[]> rows = new ArrayList<String[]>();
        int n=0;
        for(Map<String, Object> info : headList){
            n++;
            String[] dataArray = new String[5];
            dataArray[0] = n+"";
            dataArray[1] = info.get("code").toString();
            dataArray[2] = info.get("name").toString();
            dataArray[3] = info.get("type").toString();
            dataArray[4] = info.get("sum").toString();
            rows.add(dataArray);
        }

        new ExlExport().excelExport(array,rows,"财务清单","财务清单","财务清单",response);
    }
}
